<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($post->titulo) ?> | Central da Bola</title>
    <link rel="stylesheet" href="<?= base_url('styles.css') ?>">
</head>
<body>
<!-- Navegação entre a página inicial e o painel. -->
<header class="navbar"><nav class="nav-container">
    <a href="<?= base_url('/') ?>" class="nav-brand">Central da Bola</a>
    <ul class="nav-links"><li><a href="<?= base_url('/') ?>">Início</a></li><li><a href="<?= base_url('painel/posts') ?>">Painel</a></li></ul>
</nav></header>
<main class="container article-container">
    <!-- Conteúdo completo da publicação selecionada. -->
    <a class="back-link" href="<?= base_url('/') ?>">← Voltar para o início</a>
    <article class="article-card">
        <div class="post-meta">Publicado em <?= date('d/m/Y H:i', strtotime($post->created_at)) ?></div>
        <h1><?= esc($post->titulo) ?></h1>
        <div class="article-content"><?= nl2br(esc($post->conteudo)) ?></div>
    </article>
</main>
<!-- Rodapé compartilhado do site. -->
<footer class="footer">Central da Bola · <?= date('Y') ?></footer>
</body>
</html>
