<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel de publicações</title><link rel="stylesheet" href="<?= base_url('styles.css') ?>">
</head>
<body>
<!-- Navegação do painel administrativo. -->
<header class="navbar"><nav class="nav-container">
    <a href="<?= base_url('/') ?>" class="nav-brand">Central da Bola</a>
    <ul class="nav-links"><li><a href="<?= base_url('/') ?>">Ver blog</a></li><li><a href="<?= base_url('painel/posts') ?>" class="active">Publicações</a></li></ul>
</nav></header>
<main class="container">
    <!-- Título do painel e ação para cadastrar uma publicação. -->
    <div class="page-header"><div><span class="eyebrow">Administração</span><h1>Gerenciar publicações</h1><p>Cadastre, edite ou exclua as notícias do blog.</p></div>
        <a href="<?= base_url('painel/posts/inserir') ?>" class="btn btn-primary">+ Nova publicação</a>
    </div>
    <?php if (session()->getFlashdata('sucesso')): ?><div class="alert success"><?= esc(session()->getFlashdata('sucesso')) ?></div><?php endif; ?>
    <!-- Tabela de publicações e ações de gerenciamento. -->
    <div class="card">
        <?php if (empty($posts)): ?>
            <div class="empty-state"><h3>Nenhuma publicação cadastrada</h3><p>Comece criando sua primeira publicação.</p><a class="btn btn-primary" href="<?= base_url('painel/posts/inserir') ?>">Criar publicação</a></div>
        <?php else: ?>
        <div class="table-wrap"><table class="data-table"><thead><tr><th>Código</th><th>Título</th><th>Data</th><th class="actions-col">Ações</th></tr></thead><tbody>
        <?php foreach ($posts as $post): ?>
            <tr><td><?= $post->id ?></td><td class="table-title"><?= esc($post->titulo) ?></td><td><?= date('d/m/Y', strtotime($post->created_at)) ?></td>
            <td class="actions-cell"><a class="btn btn-edit" href="<?= base_url('painel/posts/editar/' . $post->id) ?>">Editar</a>
                <form method="post" action="<?= base_url('painel/posts/excluir/' . $post->id) ?>" onsubmit="return confirm('Deseja realmente excluir esta publicação?')">
                    <?= csrf_field() ?><button type="submit" class="btn btn-delete">Excluir</button>
                </form>
                <a class="btn btn-view" href="<?= base_url('post/' . $post->id) ?>" target="_blank">Visualizar</a>
            </td></tr>
        <?php endforeach; ?>
        </tbody></table></div>
        <?php endif; ?>
    </div>
</main>
<!-- Rodapé compartilhado do site. -->
<footer class="footer">Central da Bola · <?= date('Y') ?></footer>
</body></html>
