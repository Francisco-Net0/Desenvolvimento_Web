<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title><?= isset($post->id) ? 'Editar' : 'Nova' ?> publicação</title><link rel="stylesheet" href="<?= base_url('styles.css') ?>"></head>
<body>
<!-- Navegação do painel administrativo. -->
<header class="navbar"><nav class="nav-container"><a href="<?= base_url('/') ?>" class="nav-brand">Central da Bola</a><ul class="nav-links"><li><a href="<?= base_url('/') ?>">Ver blog</a></li><li><a href="<?= base_url('painel/posts') ?>" class="active">Publicações</a></li></ul></nav></header>
<main class="container form-container">
    <!-- Formulário reutilizado para criar e editar publicações. -->
    <a class="back-link" href="<?= base_url('painel/posts') ?>">← Voltar para publicações</a>
    <div class="page-header"><div><span class="eyebrow">Painel administrativo</span><h1><?= isset($post->id) ? 'Editar publicação' : 'Nova publicação' ?></h1><p>Preencha os campos abaixo para salvar a notícia.</p></div></div>
    <div class="card form-card">
        <?php if (!empty($msg)): ?><div class="alert error"><?= esc($msg) ?></div><?php endif; ?>
        <form method="post">
            <?= csrf_field() ?>
            <div class="form-group"><label for="titulo">Título</label><input type="text" id="titulo" name="titulo" maxlength="150" value="<?= esc(old('titulo', $post->titulo ?? '')) ?>" placeholder="Digite o título da publicação" required></div>
            <div class="form-group"><label for="conteudo">Conteúdo</label><textarea id="conteudo" name="conteudo" rows="14" placeholder="Escreva o conteúdo da publicação..." required><?= esc(old('conteudo', $post->conteudo ?? '')) ?></textarea></div>
            <div class="form-actions"><a href="<?= base_url('painel/posts') ?>" class="btn btn-light">Cancelar</a><button type="submit" class="btn btn-primary">Salvar publicação</button></div>
        </form>
    </div>
</main>
<!-- Rodapé compartilhado do site. -->
<footer class="footer">Central da Bola · <?= date('Y') ?></footer>
</body></html>
