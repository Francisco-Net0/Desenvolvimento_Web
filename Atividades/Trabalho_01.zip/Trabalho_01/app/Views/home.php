<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Central da Bola | Início</title>
    <link rel="stylesheet" href="<?= base_url('styles.css') ?>">
</head>
<body>
<!-- Menu principal e atalhos para o blog e o painel. -->
<header class="navbar">
    <nav class="nav-container">
        <a href="<?= base_url('/') ?>" class="nav-brand">Central da Bola</a>
        <ul class="nav-links">
            <li><a href="<?= base_url('/') ?>" class="active">Início</a></li>
            <li><a href="<?= base_url('painel/posts') ?>">Painel</a></li>
        </ul>
    </nav>
</header>
<main class="container">
    <!-- Título e listagem das publicações mais recentes. -->
    <div class="section-heading">
        <h1>Últimas postagens</h1>
    </div>

    <!-- Mostra uma mensagem vazia ou os cards recebidos do controller. -->
    <?php if (empty($posts)): ?>
        <div class="empty-state"><h3>Nenhuma publicação ainda</h3><p>As publicações adicionadas no painel aparecerão aqui.</p></div>
    <?php else: ?>
        <div class="post-list">
            <?php foreach ($posts as $post): ?>
                <article class="public-post">
                    <div class="post-meta">Publicado em <?= date('d/m/Y', strtotime($post->created_at)) ?></div>
                    <h3><?= esc($post->titulo) ?></h3>
                    <a class="read-more" href="<?= base_url('post/' . $post->id) ?>">Ler publicação <span>→</span></a>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>
<!-- Rodapé compartilhado do site. -->
<footer class="footer">Central da Bola · <?= date('Y') ?></footer>
</body>
</html>
