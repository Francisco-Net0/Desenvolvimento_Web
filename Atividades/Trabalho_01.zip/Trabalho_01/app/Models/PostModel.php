<?php

namespace App\Models;

use CodeIgniter\Model;

class PostModel extends Model
{
    // Tabela e campos que podem ser gravados pelo model.
    protected $table            = 'posts';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'object';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['titulo', 'conteudo'];

    // Preenche automaticamente as datas de criação e atualização.
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // Regras e mensagens exibidas quando os dados não são válidos.
    protected $validationRules = [
        'titulo'   => 'required|min_length[3]|max_length[150]',
        'conteudo' => 'required|min_length[5]',
    ];

    protected $validationMessages = [
        'titulo' => [
            'required'   => 'Informe o título da publicação.',
            'min_length' => 'O título deve ter pelo menos 3 caracteres.',
            'max_length' => 'O título pode ter no máximo 150 caracteres.',
        ],
        'conteudo' => [
            'required'   => 'Informe o conteúdo da publicação.',
            'min_length' => 'O conteúdo deve ter pelo menos 5 caracteres.',
        ],
    ];
}
