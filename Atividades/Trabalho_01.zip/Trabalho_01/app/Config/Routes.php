<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');
$routes->get('/post/(:num)', 'Home::visualizar/$1');

$routes->group('painel', static function ($routes) {
    $routes->get('posts', 'Posts::index');
    $routes->get('posts/inserir', 'Posts::inserir');
    $routes->post('posts/inserir', 'Posts::inserir');
    $routes->match(['get', 'post'], 'posts/editar/(:num)', 'Posts::editar/$1');
    $routes->post('posts/excluir/(:num)', 'Posts::excluir/$1');
});
