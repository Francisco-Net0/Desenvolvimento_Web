<?php

namespace App\Controllers;
class Posts extends BaseController
{
    // Exibe as publicações cadastradas no painel.
    public function index()
    {
        $postModel = model('PostModel');
        $dados['posts'] = $postModel->orderBy('created_at', 'DESC')->findAll();
        return view('painel/posts', $dados);
    }

    // Exibe o formulário e processa o cadastro de uma publicação.
    public function inserir()
    {
        $dados['msg'] = '';
        $dados['post'] = null;
        if ($this->request->is('post')) {
            $postModel = model('PostModel');
            $dadosPost = $this->request->getPost(['titulo', 'conteudo']);
            if ($postModel->insert($dadosPost)) {
                return redirect()->to(base_url('painel/posts'))->with('sucesso', 'Publicação cadastrada com sucesso.');
            }
            $dados['msg'] = 'Erro ao salvar publicação. Verifique os campos.';
            $dados['post'] = (object) $dadosPost;
        }

        return view('painel/posts_form', $dados);
    }

    // Carrega os dados atuais e processa a edição da publicação.
    public function editar($id)
    {
        $postModel = model('PostModel');
        $dados['post'] = $postModel->find($id);
        $dados['msg'] = '';
        if (!$dados['post']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Publicação não encontrada.');
        }
        if ($this->request->is('post')) {
            $dadosPost = $this->request->getPost(['titulo', 'conteudo']);
            if ($postModel->update($id, $dadosPost)) {
                return redirect()->to(base_url('painel/posts'))->with('sucesso', 'Publicação atualizada com sucesso.');
            }
            $dados['msg'] = 'Erro ao atualizar publicação. Verifique os campos.';
            $dados['post'] = (object) array_merge((array) $dados['post'], $dadosPost);
        }
        return view('painel/posts_form', $dados);
    }

    // Remove uma publicação somente quando a requisição é POST.
    public function excluir($id)
    {
        if (!$this->request->is('post')) {
            return redirect()->to(base_url('painel/posts'));
        }
        $postModel = model('PostModel');
        $postModel->delete($id);
        return redirect()->to(base_url('painel/posts'))->with('sucesso', 'Publicação excluída com sucesso.');
    }
}
