<?php

namespace App\Controllers;

class Home extends BaseController
{
    // Carrega as publicações mais recentes para a página inicial.
    public function index(): string
    {
        $postModel = model('PostModel');
        $dados['posts'] = $postModel->orderBy('created_at', 'DESC')->findAll();
        return view('home', $dados);
    }

    // Busca e exibe uma publicação específica ou responde com página não encontrada.
    public function visualizar($id)
    {
        $postModel = model('PostModel');
        $dados['post'] = $postModel->find($id);
        if (!$dados['post']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Publicação não encontrada.');
        }
        return view('post', $dados);
    }
}
