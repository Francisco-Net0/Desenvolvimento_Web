CREATE DATABASE IF NOT EXISTS blog CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE blog;

CREATE TABLE IF NOT EXISTS posts (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    titulo VARCHAR(150) NOT NULL,
    conteudo LONGTEXT NOT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DELETE FROM posts;

INSERT INTO posts (titulo, conteudo, created_at, updated_at) VALUES
(
    'Brasileirão chega à fase decisiva',
    'Com a reta final do campeonato se aproximando, cada partida ganha ainda mais importância. Os clubes lutam por posições na tabela, vaga em competições continentais e permanência na elite.',
    '2026-11-22 09:00:00',
    '2026-11-22 09:00:00'
),
(
    'Os destaques da rodada',
    'A rodada trouxe gols, viradas emocionantes e boas atuações individuais. Os atacantes foram decisivos, enquanto os goleiros ajudaram suas equipes a conquistar pontos importantes.',
    '2026-11-21 18:30:00',
    '2026-11-21 18:30:00'
),
(
    'Academia de base revela novos talentos',
    'As categorias de base continuam sendo fundamentais para o futebol brasileiro. Os jovens jogadores chegam ao profissional com técnica, velocidade e muita vontade de mostrar seu potencial.',
    '2026-11-20 14:15:00',
    '2026-11-20 14:15:00'
),
(
    'Clássico movimenta a cidade',
    'O clássico reúne milhares de torcedores em uma das maiores rivalidades do futebol. A partida promete intensidade, estratégia e muita emoção dentro e fora de campo.',
    '2026-11-19 16:45:00',
    '2026-11-19 16:45:00'
),
(
    'Como funciona a preparação antes dos jogos',
    'Treinos físicos, orientação tática e descanso são partes da rotina dos jogadores antes das partidas. A comissão técnica organiza a semana para que a equipe chegue ao jogo no melhor estado possível.',
    '2026-11-18 11:20:00',
    '2026-11-18 11:20:00'
),
(
    'Mercado da bola abre novas possibilidades',
    'As janelas de transferência movimentam os clubes e criam expectativas entre os torcedores. A busca por reforços envolve planejamento financeiro e necessidade técnica das equipes.',
    '2026-11-17 10:10:00',
    '2026-11-17 10:10:00'
);
