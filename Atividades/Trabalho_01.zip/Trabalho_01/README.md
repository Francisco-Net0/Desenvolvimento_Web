# Blog 
Aplicacao de blog desenvolvida com PHP 8 e CodeIgniter 4. Permite listar,
ler, cadastrar, editar e excluir publicacoes por um painel administrativo
didatico.

## Funcionalidades
- Lista de postagens na pagina inicial em formato de cards.
- Pagina individual para leitura de cada postagem.
- Painel para criar, editar e excluir publicacoes.
- Validacao dos campos do formulario.
- Protecao CSRF nas operacoes de escrita.
- Escape do titulo e do conteudo exibidos na interface.
- Layout responsivo e rodape fixado na parte inferior da tela.

## Requisitos
- PHP
- Composer
- MySQL


## Configuracao
1. Instale as dependencias:
   ```powershell
   composer install
   ```
2. Importe o banco de dados:
   ```powershell
   Get-Content .\blog.sql -Raw | & "C:\xampp\mysql\bin\mysql.exe" -u root
   ```
   O script cria o banco `blog` e a tabela `posts`.
3. Configure a conexao no arquivo `.env`, caso necessario:
   ```dotenv
   CI_ENVIRONMENT = development
   app.baseURL = 'http://localhost:8080/'
   database.default.hostname = localhost
   database.default.database = blog
   database.default.username = root
   database.default.password =
   database.default.DBDriver = MySQLi
   database.default.port = 3306
   ```
4. Inicie a aplicacao:
   ```powershell
   php spark serve --host 127.0.0.1 --port 8080
   ```
5. Acesse:
   - Blog: http://127.0.0.1:8080
   - Painel: http://127.0.0.1:8080/painel/posts

## Estrutura principal
```text
app/
  Controllers/
    Home.php
    Posts.php
  Models/
    PostModel.php
  Views/
    home.php
    post.php
    painel/
public/
  styles.css
blog.sql
```
